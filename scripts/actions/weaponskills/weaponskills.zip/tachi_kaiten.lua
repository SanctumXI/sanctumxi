-----------------------------------
-- Tachi Kaiten
-- Great Katana weapon skill
-- Skill level: N/A
-- Additional effect: temporarily increases amount of TP stored with each hit.
-- Grants Store TP+7 for the duration of time that it is active. Length of time depends on TP.
-- 100 TP = 20s
-- 200 TP = 40s
-- 300 TP = 60s
-- This weapon skill is only available with the stage 5 relic Great Katana Amanomurakumo or within Dynamis with the stage 4 Totsukanotsurugi.
-- Also available as a Latent effect on Ame-no-ohabari
-- Aligned with the Breeze Gorget, Thunder Gorget & Light Gorget.
-- Aligned with the Breeze Belt, Thunder Belt & Light Belt.
-- Element: None
-- Modifiers: STR:75%
-- 100%TP    200%TP    300%TP
-- 3.00      3.00      3.00
-----------------------------------
---@type TWeaponSkill
local weaponskillObject = {}

weaponskillObject.onUseWeaponSkill = function(player, target, wsID, tp, primary, action, taChar)
    local params = {}
    params.numHits = 1
    params.ftpMod = { 2.75, 2.75, 2.75 }
    params.str_wsc = 0.6

    if xi.settings.main.USE_ADOULIN_WEAPON_SKILL_CHANGES then
        params.str_wsc = 0.8
    end

    -- Apply aftermath
    xi.aftermath.addStatusEffect(player, tp, xi.slot.MAIN, xi.aftermath.type.RELIC)

    local damage, criticalHit, tpHits, extraHits = xi.weaponskills.doPhysicalWeaponskill(player, target, wsID, params, tp, action, primary, taChar)

    return tpHits, extraHits, criticalHit, damage
end

return weaponskillObject
